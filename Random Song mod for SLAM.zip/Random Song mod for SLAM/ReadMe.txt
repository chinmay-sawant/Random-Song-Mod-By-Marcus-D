>>>>>>>Random Song Number(Mod For SLAM)<<<<<<<
>>>>>>>Based On python<<<<<<<<<<<<<<<
>>>>>>>>>>If anything happen to your csgo/steam account i am not responsible for anything<<<<<<<<<<<
>>>>>>>>>>Use on OWN RESPONSIBILITY<<<<<<<<<<<<<<<<<<<<<
/////////////You'll not get vac banned for using simple application dont worry\\\\\\\\\\\\\\\\\\\\\ 


==============================================
For Any Enquiry Regarding This Projekt Add Me Or visit my website for my profile link 
steam link:-
https://steamcommunity.com/id/marcus06/
website:-
https://chinmay-sawant.github.io
==============================================

-------------Requirements----------------
1.SLAM Installed
---------------------------------------


1.Extract all files on pc 

2.Put random.cfg and random.py in 
E:\SteamLibrary\steamapps\common\Counter-Strike Global Offensive\csgo\cfg


**Right click on random.py and make shortcut on desktop**


i.e in your cfg folder
(in my case i have installed on E: drive )

3.Open IDLE(Python GUI)

4.Click on file>open>go to desktop(coz we created shortcut to random.py link) Click on shortcut of random.py open it

5.Execute it(Press F5) in background dont close shell

6.Ingame type in console:-
bind "\" "exec random"


