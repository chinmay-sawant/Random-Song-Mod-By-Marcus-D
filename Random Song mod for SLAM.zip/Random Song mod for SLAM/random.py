from random import *
import time
while True:
    f= open("random.cfg","w+")
    f.write("");
    x = randint(1,219);
    x1=str(x);
    f.write(x1);
    f.close();
    time.sleep(10);
    print("Executing again MOD By Marcus:P");
    



